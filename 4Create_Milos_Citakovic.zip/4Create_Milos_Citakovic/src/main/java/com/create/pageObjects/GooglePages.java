package com.create.pageObjects;

import com.create.utils.CommonGoogle;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

public class GooglePages extends CommonGoogle {

    protected static String txtInputField = "q";
    protected static String listResults = "rso";
    protected static String lnkLanguage = "//*[@id=\"SIvCob\"]/a[1]";

    protected static void changeLanguage(String actualLanguage) {
        if(driver.findElement(By.xpath(lnkLanguage)).getText().equals(actualLanguage)) {
            driver.findElement(By.xpath(lnkLanguage)).click();
        }
    }

    protected static void searchForTerm(String term) {
        driver.findElement(By.name(txtInputField)).sendKeys(term);
        driver.findElement(By.name(txtInputField)).sendKeys(Keys.ENTER);

        // wait until the google page shows the result
        WebElement myDynamicElement = (new WebDriverWait(driver, 3))
                .until(ExpectedConditions.presenceOfElementLocated(By.id("rso")));
    }

    protected static List<WebElement> takeResults() {
        return driver.findElements(By.className("g"));
    }
}