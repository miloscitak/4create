package com.create.pageObjects;

import com.create.utils.CommonGmail;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class GmailPages extends CommonGmail {

    private static String btnLogin = "/html/body/header/div/ol[2]/li[2]/a[1]";
    private static String btnWithGoogle = "//*[@id=\"openid-buttons\"]/button[1]";
    private static String txtEmail = "identifierId";
    private static String btnDalje = "//*[@id=\"identifierNext\"]/div/button/div[2]";
    private static String txtPassword = "password";
    private static String btnDalje2 = "//*[@id=\"passwordNext\"]/div/button/div[2]";

    private static String unreadEmail = "zE";

    private static String btnMenu = "gbii";
    private static String btnSignOut = "gb_71";

    protected static void loginToGoogle() {


        driver.findElement(By.id(txtEmail)).sendKeys("kovacevicp101@gmail.com");

        driver.findElement(By.xpath(btnDalje)).click();

        // wait password page
        /*WebElement myDynamicElement = (new WebDriverWait(driver, 3))
                .until(ExpectedConditions.presenceOfElementLocated(By.name(txtPassword)));*/
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        driver.findElement(By.name(txtPassword)).sendKeys("R@bb!txy");

        driver.findElement(By.xpath(btnDalje2)).click();


    }

    protected static List<WebElement> checkUnreadMails() {
        // wait emails page
        /*WebElement myDynamicElement = (new WebDriverWait(driver, 10))
                .until(ExpectedConditions.presenceOfElementLocated(By.className(unreadEmail)));*/
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        return driver.findElements(By.className(unreadEmail));
    }

    protected static void logout() {
        driver.findElement(By.className(btnMenu)).click();
        driver.findElement(By.id(btnSignOut)).click();
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    }
}
