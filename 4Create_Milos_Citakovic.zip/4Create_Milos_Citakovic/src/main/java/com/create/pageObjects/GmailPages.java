package com.create.pageObjects;

import com.create.utils.CommonGmail;
import org.openqa.selenium.By;

public class GmailPages extends CommonGmail {

    protected static String btnLogin = "/html/body/header/div/ol[2]/li[2]/a[1]";

    protected static String btnWithGoogle = "//*[@id=\"openid-buttons\"]/button[1]";

    protected static String lnkAnotherAccount = "JDAKTe:nth-child(2) .BHzsH";

    protected static String txtEmail = "identifierId";
    protected static String btnDalje = "//*[@id=\"identifierNext\"]/div/button/div[2]";

    protected static String btnPrijaviMe = "/html/body/div[2]/div[1]/div[4]/ul[1]/li[2]/a";

    protected static void tryToLoginToGoogle() {
        driver.findElement(By.xpath(btnLogin)).click();

        driver.findElement(By.xpath(btnWithGoogle)).click();

        driver.findElement(By.id(txtEmail)).sendKeys("sender1984test@gmail.com");

        driver.findElement(By.xpath(btnDalje)).click();
    }
}
