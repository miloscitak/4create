package com.create;

import com.create.pageObjects.GmailPages;
import net.bytebuddy.implementation.bind.MethodDelegationBinder;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class Gmail extends GmailPages {

    @Test
    public void unreadEmailsExistsGmail() {

        loginToGoogle();

        List<WebElement> unreadEmails = checkUnreadMails();

        Assert.assertTrue(unreadEmails.size() > 0);

        logout();

    }
}
