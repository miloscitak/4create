package com.create;

import com.create.pageObjects.GmailPages;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

public class Gmail extends GmailPages {

    @Test
    public void loginToGmail() {

        GmailPages.tryToLoginToGoogle();

    }
}
