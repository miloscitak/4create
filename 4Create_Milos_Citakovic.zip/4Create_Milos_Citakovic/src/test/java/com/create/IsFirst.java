package com.create;

import com.create.pageObjects.GooglePages;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

public class IsFirst extends GooglePages {

    @Test
    public void isResultFirstEng() {

        GooglePages.changeLanguage("српски");

        GooglePages.searchForTerm("4create");

        List<WebElement> findElements = GooglePages.takeResults();

        Assert.assertTrue(findElements.get(0).getText().contains("4Create - Modernizing healthcare software"));

    }

    @Test
    public void isResultFirstSerbian() {

        GooglePages.changeLanguage("English");

        GooglePages.searchForTerm("4create");

        List<WebElement> findElements = GooglePages.takeResults();

        Assert.assertTrue(findElements.get(0).getText().contains("4Create - Modernizing healthcare software"));

    }
}
